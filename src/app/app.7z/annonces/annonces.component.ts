import { Annonce } from '../shared/interface/annonce.inteface';
import {Component, Input, OnInit} from '@angular/core';
import { ListeAnnoncesService } from '../shared/services/liste-annonces.service';
import {HttpClient} from "@angular/common/http";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-annonces',
  templateUrl: './annonces.component.html',
  styleUrls: ['./annonces.component.scss']
})
export class AnnoncesComponent implements OnInit {
  annonces:Annonce[]=[];
  selectedAnnonce!:any;
  constructor(private http: HttpClient,private router: Router,
              private route: ActivatedRoute,
              private listeAnnoncesServ: ListeAnnoncesService) { }

  receiveChildrenEvt(Annonce: Annonce): void {
    this.selectedAnnonce = Annonce;
  }

  ngOnInit(): void {
    this.listeAnnoncesServ.findAll().subscribe(r => this.annonces = r);
  }
}


