import {ListeAnnoncesService} from '../shared/services/liste-annonces.service';
import {Component, Input, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {HttpClient} from "@angular/common/http";
import {Annonce} from "../shared/modele/annonce.model";


@Component({
  selector: 'app-annonces-details',
  templateUrl: './annonces-details.component.html',
  styleUrls: ['./annonces-details.component.scss']
})
export class AnnoncesDetailsComponent implements OnInit {
  annonce:any;

  constructor(private http: HttpClient,
              private route: ActivatedRoute,
              private listeAnnoncesServ: ListeAnnoncesService, router: Router) {
  }


  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id') || -1;
    this.listeAnnoncesServ.findOne(+id).subscribe(v => this.annonce = v);
  }


}
